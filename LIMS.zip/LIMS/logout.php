<?php
session_start();
$_SESSION["id"]=null;
$_SESSION['adm']=null;
header('Location:index.php');
?>