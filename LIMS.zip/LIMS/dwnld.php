<?php
session_start();
 $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "instruments";
                $conn = new mysqli($servername, $username, $password, $dbname);
$sql=$_SESSION['xl'];
$result = $conn->query($sql);
$data="";
$header="";

while($row = $result->fetch_assoc()){
   $line = '';
   foreach($row as $value){
          if(!isset($value) || $value == ""){
                 $value = "\t";
          }else{
                 $value = str_replace('"', '""', $value);
                 $value = '"' . $value . '"' . "\t";
                 }
          $line .= $value;
          }
   $data .= trim($line)."\n";
   $data = str_replace("\r", "", $data);

if ($data == "") {
   $data = "\nno matching records found\n";
   }
}


header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: attachment; filename=exportfile.xls");
header("Pragma: no-cache");
header("Expires: 0");

// output data
echo $header."\n".$data;
?>