<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Log in</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
    <style>
        form{
            height: 500px;
            width: 500px;
            margin-top: 75px;
            border-radius: 20px;
        }
        footer{
            margin-top:48px;
        }
        nav div{
            margin-left: 500px;
            font-size: 25px;
            color: white;
            font-family: 'Open Sans', sans-serif;
        }
        
        .back{
            height : 50px;   
        }
    
    </style>
</head>

<body>
    
        <nav class="navbar navbar-dark indigo animated zoomIn">
            <div class="college-name">
               <center>Lab Management System  - Main Admin</center>
            </div>
        </nav>
    


    <!--Login Page    -->
    <!-- Default form login -->
    <center>
        <form action="mlogval.php" method="post"class="text-center border border-light p-5 animated zoomIn">

            <p class="h4 mb-4">Log In</p>
            <input type="text" name="AUname" class="form-control mb-4" placeholder="Admin Username">
            <input type="password" name="Apass" class="form-control mb-4" placeholder="Admin Password">
            <button class="btn btn-info btn-block my-4" type="submit">Sign in</button>
        </form>
    </center>


<!-- Central Modal Small -->
<!-- Default form login -->
    
    <!-- Footer -->
<footer class="page-footer font-small blue animated zoomIn">

  <!-- Copyright -->
  
  <!-- Copyright -->

</footer>
<!-- Footer -->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
</body>

</html>
