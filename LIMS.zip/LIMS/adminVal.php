<?php
$servername ="localhost";
$username ="root";
$password ="";
$auname=$_POST["AUname"];
$apass=$_POST["Apass"];
$pass="  ";
$id=-1;
$conn = mysqli_connect($servername, $username, $password,"instruments");
session_destroy();
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql="select * from subregister where usrname='$auname'";
$result=$conn->query($sql);
//if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $pass=$row['passwd'];
                    $id=$row['id'];
                    }
          //      }

if($pass==$apass){
    session_start();
    $_SESSION['id']=$id;
    $_SESSION['adm']="yes";
    header('Location:hme.php');
    
}
else{
  header('Location: login.html');
}
mysqli_close($conn);
?>