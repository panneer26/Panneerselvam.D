<?php
$servername ="localhost";
$username ="root";
$password ="";
$auname=$_POST["AUname"];
$apass=$_POST["Apass"];
$pass="  ";
$id=-1;
$conn = mysqli_connect($servername, $username, $password,"instruments");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql="select * from Admin where username='$auname'";
$result=$conn->query($sql);
 while(($row = $result->fetch_assoc())!== null) {
        $pass= $row["passwd"];
        $id=$row["id"];
    }
if($pass==$apass){
    session_start();
    $_SESSION['id']=$id;
    header('Location:mainAdm.php');
    
}
else{
   header('Location: mlogin.php');
}
  if(!(isset($_POST['AUname'])||isset($_POST['Apass']))){
        echo "-->";
    }
mysqli_close($conn);
?>