<?php
    session_start();
 if($_SESSION['id']==null){
     header('Location:mlogin.php');
 }


?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>Lab Instrument Management</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
    <link rel="shortcut icon" href="img/sourceImg/ksricon.png" type="image/x-icon">
    <style>
        nav div {
            font-size: 25px;
            color: white;
            font-family: 'Open Sans', sans-serif;
        }
        .outer .outer-col{
            border: 2px  solid blue;
            border-right: none;
            border-top: none;
            border-bottom:none;
            height: 710px;
            width: 100%;
        }
        input,button{
            border-radius: 5px;
            margin-top: 40px;
            margin-left: 50px;
            margin-right: 50px;
            width:80%;
        }
        .back{
            height : 50px;   
        }
        table{
            text-align: center;
        }
        button.ad{
            background-color: aqua; 
            float: right;
        }
        
    </style>
</head>

<body>
    
    <nav class="navbar navbar-dark indigo animated zoomIn">
        <div class="college-name" style="margin-right=50px">
            Lab Instrument Management System- Main Admin
        </div>
            <div>
                <a href="logout.php"><button class="ad">Log-Out</button></a>
            </div>
    </nav>
      <div class="back" style="background-color:DodgerBlue;margin-top:5px;">
             <a href="view.php"><button style="margin-top:10px;width:40%;background-color:white">View Admin</button></a>
             <a href="delete.php"><button style="margin-top:10px;float:right;width:40%;background-color:white">Remove Admin</button></a>
         
    </div>
    <div class="container-fluid">
      <div class="row outer">
        <div class="outer-col col-sm-6 col-lg-6 col-md-6">
          <button type="button" class="btn btn-purple" style="width: 100%">Add Lab Admin</button>
            <center>
        <form action="addadm.php" method="post"class="text-center border border-light p-3 animated zoomIn" style="margin-top:90px">

            <p class="h4 mb-2">Add Admin</p>
            <!-- Email -->
            <input type="text" name="sAname"  placeholder="Admin name">
            <input type="text" name="sAUname"  placeholder="Admin User name">
            <input type="text" name="labname"  placeholder="Labarotary Name">
            <input type="password" name="sApass" placeholder="Admin Password">
            <!-- Sign in button -->
            <button class="btn btn-info btn-block my-4" type="submit">Add</button>


        </form>
    </center>
        </div>
        
        <div class="outer-col col-sm-6 col-lg-6 col-md-6">
          <button type="button" class="btn btn-purple" style="width: 100%">View Status</button>
             <center>
        <form action="viewreg.php" method="post"class="text-center border border-light p-3 animated zoomIn" style="margin-top:90px">

            <p class="h4 mb-2">View Register</p>
            <!-- Email -->
            <input type="text" name="lname" list="dat" placeholder="Laboratory Name">
            <datalist id="dat">
                <select>
                    <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "instruments";
                $conn = new mysqli($servername, $username, $password, $dbname);
                $sql = "SELECT * FROM labs";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $tmp=$row['name'];
                        echo '<option value="'.substr($tmp,3).'"></option>';
                        }
                    }
                    ?>
                </select>
            </datalist>
            <!-- Sign in button -->
            <button class="btn btn-info btn-block my-4" type="submit">View</button>


        </form>
    </center>
        </div>
      </div>
    </div>
    
    
<footer class="page-footer font-small blue animated zoomIn">

  
</footer>

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
</body>

</html>
