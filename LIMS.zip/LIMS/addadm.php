<?php
    session_start();
 if($_SESSION['id']==null){
     header('Location:mlogin.php');
 }
if($_SESSION['adm']!=null){
     header('Location:mlogin.php');
 }
$servername ="localhost";
$username ="root";
$password ="";
$sname=$_POST["sAname"];
$sauname=$_POST["sAUname"];
$sapass=$_POST["sApass"];
$lname=$_POST["labname"];
$conn = mysqli_connect($servername, $username, $password,"instruments");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$stmt = $conn->prepare("INSERT INTO subRegister (name,usrname,passwd,lname) values ('$sname','$sauname','$sapass','lab$lname')");
$stmt->execute();
$stmt->close();
$stmt = $conn->prepare("INSERT INTO labs values ('lab$lname')");
$stmt->execute();
$stmt->close();
$sql = "CREATE TABLE lab$lname (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
name VARCHAR(30) NOT NULL,
item VARCHAR(50),
quantity VARCHAR(20),
reg_date TIMESTAMP
)";
$conn->query($sql);
mysqli_close($conn);
header('Location:mainAdm.php');
?>